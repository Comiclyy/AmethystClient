package me.Comicly_.AmethystClient.module;

public enum Category {

    Combat,
    Movement,
    Render,
    Player,
    Gui,
    Hud

}
